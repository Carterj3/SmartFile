A [SmartFile](http://www.smartfile.com/) Open Source project. [Read more](http://www.smartfile.com/open-source.html) about how SmartFile uses and contributes to Open Source software.

![SmartFile](http://www.smartfile.com/images/logo.jpg)

SmartFile API Client (C#)
====

About
-----
This is a fully working API client for SmartFile. It allows you to interact with all objects within the SmartFile system via the REST API. This client library can be used as-is for your integration projects.


Contributors
----
 * Ben Timby <btimby@gmail.com>
